# 
# Author: Alexei Belous
# License: Public Domain
# SimpITy (https://simpity.eu/), 2026
# 
# Educational/Research purposes only - use in controlled environments only

# Clear any previous errors
$Error.Clear()

Set-Location -Path $PSScriptRoot

# Check EasyHook DLL path
$easyHookPath = ".\EasyHook-2.7.6789.0-Binaries\projects\easyhook\Deploy\NetFX4.0\EasyHook.dll"
if (-not (Test-Path $easyHookPath)) {
    Write-Host "ERROR: EasyHook.dll not found at specified path:" -ForegroundColor Red
    Write-Host "  $easyHookPath" -ForegroundColor Yellow
    exit 1
}

Write-Host "=== SetPassword Protection Hook ===" -ForegroundColor Cyan
Write-Host "Log file: C:\Windows\Temp\SetPassword_Hook.log" -ForegroundColor Cyan
Write-Host "WARNING: For educational/research use only!" -ForegroundColor Red
Write-Host "===========================" -ForegroundColor Cyan

# Let's load EasyHook assembly
try {
    Write-Host "Loading EasyHook from: $easyHookPath" -ForegroundColor Yellow
    Add-Type -Path $easyHookPath
    Write-Host "EasyHook assembly loaded successfully" -ForegroundColor Green
}
catch {
    Write-Host "ERROR: Failed to load EasyHook.dll: $_" -ForegroundColor Red
    exit 1
}

# Get lsass.exe process
$lsassProcess = Get-Process lsass -ErrorAction SilentlyContinue
if (-not $lsassProcess) {
    Write-Host "ERROR: lsass.exe process not found." -ForegroundColor Red
    exit 1
}

Write-Host "Found lsass.exe process (PID: $($lsassProcess.Id))" -ForegroundColor Green

# Create a temporary directory
$tempDir = Join-Path $PSScriptRoot "Temp"
New-Item -ItemType Directory -Path $tempDir -Force | Out-Null

try {
    Write-Host "Creating injection DLL..." -ForegroundColor Yellow
    
    # Create a C# file with correct signatures based on error messages
    # We need to use REMOTE_ENTRY_INFO instead of RemoteHooking.IContext
    $csCode = @'
using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using EasyHook;

namespace LSAHookNamespace
{
    public class LSAHookEntryPoint : IEntryPoint
    {
        // Constants for SAMR_USER_INFORMATION_CLASS
        private const int UserGeneralInformation = 1;
        private const int UserPreferencesInformation = 2;
        private const int UserLogonInformation = 3;
        private const int UserLogonHoursInformation = 4;
        private const int UserAccountInformation = 5;
        private const int UserNameInformation = 6;
        private const int UserAccountNameInformation = 7;
        private const int UserFullNameInformation = 8;
        private const int UserPrimaryGroupInformation = 9;
        private const int UserHomeInformation = 10;
        private const int UserScriptInformation = 11;
        private const int UserProfileInformation = 12;
        private const int UserAdminCommentInformation = 13;
        private const int UserWorkStationsInformation = 14;
        private const int UserSetPasswordInformation = 15;
        private const int UserControlInformation = 16;
        private const int UserExpiresInformation = 17;
        private const int UserInternal1Information = 18;
        private const int UserInternal2Information = 19;
        private const int UserParametersInformation = 20;
        private const int UserAllInformation = 21;
        private const int UserInternal3Information = 22;
        private const int UserInternal4Information = 23;
        private const int UserInternal5Information = 24;
        private const int UserInternal4InformationNew = 25;
        private const int UserInternal5InformationNew = 26;
        private const int UserInternal6Information = 27;
        private const int UserExtendedInformation = 28;
        private const int UserLogonUIInformation = 29;

        [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
        private static extern IntPtr GetModuleHandle(string lpModuleName);
        
        [DllImport("kernel32.dll", CharSet = CharSet.Ansi, ExactSpelling = true)]
        private static extern IntPtr GetProcAddress(IntPtr hModule, string procName);
        
        [UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Unicode)]
        private delegate int SamrSetInformationUserDelegate(IntPtr UserHandle, int UserInformationClass, IntPtr Buffer);
        
        private LocalHook _setInfoHook;
        private SamrSetInformationUserDelegate _originalSetInformationFunction;
        private string _logPath;
        private string _channelName;
        
        public LSAHookEntryPoint(
            object context,
            string channelName,
            string param2)
        {
            _channelName = channelName;
            _logPath = Path.Combine("C:\\Windows\\Temp", "SetPassword_Hook.log");
            LogToFile("LSAHookEntryPoint constructor called with 3 parameters");
            LogToFile("Channel name: " + channelName);
            LogToFile("Param2: " + param2);
        }
        
        // Also create constructor with 2 parameters for compatibility
        public LSAHookEntryPoint(
            object context,
            string channelName)
        {
            _channelName = channelName;
            _logPath = Path.Combine("C:\\Windows\\Temp", "SetPassword_Hook.log");
            LogToFile("LSAHookEntryPoint constructor called with 2 parameters");
            LogToFile("Channel name: " + channelName);
        }
        
        // Run method with 3 parameters: Run(REMOTE_ENTRY_INFO, string, string, string)
        public void Run(
            object context,
            string channelName,
            string param2,
            string param3)
        {
            try
            {
                LogToFile("LSAHookEntryPoint Run method starting with 4 parameters total");
                LogToFile("Channel name: " + channelName);
                LogToFile("Param2: " + param2);
                LogToFile("Param3: " + param3);
                
                InstallHooks();
                LogToFile("LSAHookEntryPoint installed successfully, entering main loop");
                
                // Signal that injection is complete
                RemoteHooking.WakeUpProcess();
                
                while (true)
                {
                    System.Threading.Thread.Sleep(1000);
                }
            }
            catch (Exception ex)
            {
                LogToFile("Error in Run method: " + ex.ToString());
            }
        }
        
        // Run method with 2 parameters: Run(REMOTE_ENTRY_INFO, string, string)
        public void Run(
            object context,
            string channelName,
            string param2)
        {
            try
            {
                LogToFile("LSAHookEntryPoint Run method starting with 3 parameters total");
                LogToFile("Channel name: " + channelName);
                LogToFile("Param2: " + param2);
                
                InstallHooks();
                LogToFile("LSAHookEntryPoint installed successfully, entering main loop");
                
                RemoteHooking.WakeUpProcess();
                
                while (true)
                {
                    System.Threading.Thread.Sleep(1000);
                }
            }
            catch (Exception ex)
            {
                LogToFile("Error in Run method: " + ex.ToString());
            }
        }

        
        // Run method with 1 parameter: Run(REMOTE_ENTRY_INFO, string)
        public void Run(
            object context,
            string channelName)
        {
            try
            {
                LogToFile("LSAHookEntryPoint Run method starting with 2 parameters total");
                LogToFile("Channel name: " + channelName);
                
                InstallHooks();
                LogToFile("LSAHookEntryPoint installed successfully, entering main loop");
                
                RemoteHooking.WakeUpProcess();
                
                while (true)
                {
                    System.Threading.Thread.Sleep(1000);
                }
            }
            catch (Exception ex)
            {
                LogToFile("Error in Run method: " + ex.ToString());
            }
        }
        
        private void InstallHooks()
        {
            try
            {
                LogToFile("Attempting to install hooks...");
                
                IntPtr samsrv = GetModuleHandle("samsrv.dll");
                if (samsrv == IntPtr.Zero)
                {
                    LogToFile("Failed to get handle to samsrv.dll");
                    return;
                }
                
                LogToFile("samsrv.dll handle: 0x" + samsrv.ToInt64().ToString("X"));
                
                IntPtr setInfoAddr = GetProcAddress(samsrv, "SamrSetInformationUser");
                if (setInfoAddr != IntPtr.Zero)
                {
                    LogToFile("SamrSetInformationUser address: 0x" + setInfoAddr.ToInt64().ToString("X"));
                    _originalSetInformationFunction = (SamrSetInformationUserDelegate)Marshal.GetDelegateForFunctionPointer(setInfoAddr, typeof(SamrSetInformationUserDelegate));
                    _setInfoHook = LocalHook.Create(setInfoAddr, new SamrSetInformationUserDelegate(SamrSetInformationUser_Hooked), this);
                    _setInfoHook.ThreadACL.SetExclusiveACL(new int[0]);
                    LogToFile("SamrSetInformationUser hook installed successfully");
                }
                else
                {
                    LogToFile("Failed to find SamrSetInformationUser address");
                }
            }
            catch (Exception ex)
            {
                LogToFile("Error in InstallHooks: " + ex.ToString());
            }
        }
        
        private bool ShouldBlockOperation(int informationClass)
        {
            // Block only password change operation
            switch (informationClass)
            {
                case UserSetPasswordInformation:      // Password changes
                case UserInternal1Information:        // Password changes - second approach
                    return true;
                
                // Allow these operations
                case UserAccountInformation:          // Account flags (disabled, locked, etc.)
                case UserControlInformation:          // User control flags
                case UserLogonInformation:            // Logon information
                case UserLogonHoursInformation:       // Logon hours
                case UserWorkStationsInformation:     // Workstations restriction
                case UserExpiresInformation:          // Account expiration
                case UserFullNameInformation:         // Display name
                case UserAdminCommentInformation:     // Description/comments
                case UserHomeInformation:             // Home directory
                case UserScriptInformation:           // Logon script
                case UserProfileInformation:          // Profile path
                default:
                    return false;
            }
        }

        private int SamrSetInformationUser_Hooked(IntPtr UserHandle, int UserInformationClass, IntPtr Buffer)
        {
            if (ShouldBlockOperation(UserInformationClass))
            {
                string blockedMessage = string.Format("[{0}] BLOCKED: SamrSetInformationUser with InformationClass: {1} ({2})", 
                    DateTime.Now, GetInformationClassName(UserInformationClass), UserInformationClass);
                LogToFile(blockedMessage);
                
                // Return STATUS_ACCESS_DENIED (0xC0000022)
                return unchecked((int)0xC0000022L);
            }
            else
            {
                // Allow the call to proceed for non-sensitive operations
                LogToFile(string.Format("ALLOWED: SamrSetInformationUser with InformationClass: {0}", GetInformationClassName(UserInformationClass)));
                return _originalSetInformationFunction(UserHandle, UserInformationClass, Buffer);
            }
        }
        
        private string GetInformationClassName(int infoClass)
        {
            switch (infoClass)
            {
                case UserGeneralInformation: return "UserGeneralInformation";
                case UserPreferencesInformation: return "UserPreferencesInformation";
                case UserLogonInformation: return "UserLogonInformation";
                case UserLogonHoursInformation: return "UserLogonHoursInformation";
                case UserAccountInformation: return "UserAccountInformation";
                case UserNameInformation: return "UserNameInformation";
                case UserAccountNameInformation: return "UserAccountNameInformation";
                case UserFullNameInformation: return "UserFullNameInformation";
                case UserPrimaryGroupInformation: return "UserPrimaryGroupInformation";
                case UserHomeInformation: return "UserHomeInformation";
                case UserScriptInformation: return "UserScriptInformation";
                case UserProfileInformation: return "UserProfileInformation";
                case UserAdminCommentInformation: return "UserAdminCommentInformation";
                case UserWorkStationsInformation: return "UserWorkStationsInformation";
                case UserSetPasswordInformation: return "UserSetPasswordInformation";
                case UserControlInformation: return "UserControlInformation";
                case UserExpiresInformation: return "UserExpiresInformation";
                case UserInternal1Information: return "UserInternal1Information";
                case UserInternal2Information: return "UserInternal2Information";
                case UserParametersInformation: return "UserParametersInformation";
                case UserAllInformation: return "UserAllInformation";
                case UserInternal3Information: return "UserInternal3Information";
                case UserInternal4Information: return "UserInternal4Information";
                case UserInternal5Information: return "UserInternal5Information";
                case UserInternal4InformationNew: return "UserInternal4InformationNew";
                case UserInternal5InformationNew: return "UserInternal5InformationNew";
                case UserInternal6Information: return "UserInternal6Information";
                case UserExtendedInformation: return "UserExtendedInformation";
                case UserLogonUIInformation: return "UserLogonUIInformation";
                default: return string.Format("Unknown (0x{0:X})", infoClass);
            }
        }
        
        private void LogToFile(string message)
        {
            try
            {
                string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
                string logEntry = string.Format("[{0}] {1}\r\n", timestamp, message);
                File.AppendAllText(_logPath, logEntry, Encoding.UTF8);
            }
            catch { }
        }
    }
}
'@
    
    $csFilePath = Join-Path $tempDir "LSAHook.cs"
    Set-Content -Path $csFilePath -Value $csCode -Encoding UTF8
    
    Write-Host "C# source file created" -ForegroundColor Gray
    
    # Compile 64-bit DLL
    $cscPath = Join-Path ${env:windir} "Microsoft.NET\Framework64\v4.0.30319\csc.exe"
    
    if (-not (Test-Path $cscPath)) {
        Write-Host "ERROR: 64-bit C# compiler not found" -ForegroundColor Red
        exit 1
    }
    
    Write-Host "Compiling 64-bit DLL..." -ForegroundColor Yellow
    
    $dllPath = Join-Path $tempDir "LSAHook64.dll"
    
    & $cscPath /target:library /platform:x64 /out:"$dllPath" /reference:"$easyHookPath" /reference:System.dll /reference:System.Core.dll "$csFilePath" 2>&1 | Out-Null
    
    if (Test-Path $dllPath) {
        Write-Host "64-bit DLL compiled successfully" -ForegroundColor Green
        Write-Host "DLL size: $((Get-Item $dllPath).Length) bytes" -ForegroundColor Gray
        
        # Now attempt injection with different parameter combinations
        Write-Host "Attempting to inject DLL into lsass.exe..." -ForegroundColor Yellow
        
        $channelName = "LSAHookChannel_" + [Guid]::NewGuid().ToString()
        
        Write-Host "Trying injection..." -ForegroundColor Yellow
        try {
            [EasyHook.RemoteHooking]::Inject($lsassProcess.Id, $dllPath, $dllPath, "LSAHookNamespace.LSAHookEntryPoint", $channelName)
            Write-Host "SUCCESS: Injection completed!" -ForegroundColor Green
        }
        catch {
            Write-Host "Injection failed: $_" -ForegroundColor Red

            # Check if it's a PPL issue
            if ($_.Exception.Message -match "access denied") {
                Write-Host "" -ForegroundColor White
                Write-Host "ACCESS DENIED - LSASS is protected" -ForegroundColor Red
                Write-Host "  1. Windows Security blocked the injection" -ForegroundColor Yellow
                Write-Host "  2. Credential Guard is enabled" -ForegroundColor Yellow
                Write-Host "  3. Some Antivirus sofware blocks it" -ForegroundColor Yellow
                Write-Host "  4. Permission issues with lsass.exe" -ForegroundColor Yellow
            }
            exit 1
        }
        
        # If we get here, injection succeeded
        $logFile = "C:\Windows\Temp\SetPassword_Hook.log"
        Write-Host "" -ForegroundColor White
        Write-Host "Monitoring log file: $logFile" -ForegroundColor Yellow
        Write-Host "Press Ctrl+C to stop monitoring" -ForegroundColor Yellow
        
        # Wait for logs
        Start-Sleep -Seconds 5
        
        if (Test-Path $logFile) {
            Write-Host "Log file contents:" -ForegroundColor Cyan
            Get-Content $logFile | ForEach-Object {
                Write-Host "  $_" -ForegroundColor Gray
            }
        }
        else {
            Write-Host "Log file not created. The hook might not be working." -ForegroundColor Yellow
        }
        
        # Monitor for blocked attempts
        Write-Host "" -ForegroundColor White
        Write-Host "Waiting for blocked password modification attempts..." -ForegroundColor Cyan
        Write-Host "Try changing a user password to test the hook" -ForegroundColor Cyan
        Write-Host "`nIMPORTANT: " -ForegroundColor Yellow
        Write-Host "`nTo remove the hooks reboot the system." -ForegroundColor Yellow
    }
    else {
        Write-Host "ERROR: 64-bit compilation failed" -ForegroundColor Red
    }
}
catch {
    Write-Host "ERROR: Script execution failed: $_" -ForegroundColor Red
}

# Clean up
if (Test-Path $tempDir) {
    Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue
}

Write-Host "Press Ctrl+C to exit" -ForegroundColor Gray
while ($true) {
    Start-Sleep -Seconds 10
}