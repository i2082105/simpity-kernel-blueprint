# 
# Author: Alexei Belous
# License: Public Domain
# SimpITy (https://simpity.eu/), 2026
# 
# Educational/Research purposes only - use in controlled environments only

param(
    [Parameter(Mandatory = $true)][string]$UserName,
    [Parameter(Mandatory = $true)][string]$NewPassword
)

Add-Type -Language CSharp -TypeDefinition @"
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

public static class SetNtlmHelper
{
    [StructLayout(LayoutKind.Sequential)]
    private struct UNICODE_STRING
    {
        public ushort Length;
        public ushort MaximumLength;
        public IntPtr Buffer;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct SAMPR_USER_INTERNAL1_INFORMATION
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
        public byte[] NTHash;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
        public byte[] LMHash;
        public byte NtPasswordPresent;
        public byte LmPasswordPresent;
        public byte PasswordExpired;
        public byte PrivateDataSensitive;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct SAMPR_USER_INFO_BUFFER
    {
        public SAMPR_USER_INTERNAL1_INFORMATION Internal1;
    }

    private enum USER_INFORMATION_CLASS
    {
        UserSetPasswordInformation = 15,
        UserInternal1Information = 18,
        UserAllInformation = 21
    }

    [DllImport("samlib.dll", CharSet = CharSet.Unicode)]
    private static extern int SamConnect(
        ref UNICODE_STRING ServerName,
        out IntPtr ServerHandle,
        uint DesiredAccess,
        bool Trusted);

    [DllImport("samlib.dll", CharSet = CharSet.Unicode)]
    private static extern int SamLookupDomainInSamServer(
        IntPtr ServerHandle,
        ref UNICODE_STRING Name,
        out IntPtr DomainId);

    [DllImport("samlib.dll")]
    private static extern int SamOpenDomain(
        IntPtr ServerHandle,
        uint DesiredAccess,
        IntPtr DomainId,
        out IntPtr DomainHandle);

    [DllImport("samlib.dll", CharSet = CharSet.Unicode)]
    private static extern int SamLookupNamesInDomain(
        IntPtr DomainHandle,
        uint Count,
        UNICODE_STRING[] Names,
        out IntPtr RelativeIds,
        out IntPtr Use);

    [DllImport("samlib.dll")]
    private static extern int SamOpenUser(
        IntPtr DomainHandle,
        uint DesiredAccess,
        uint UserId,
        out IntPtr UserHandle);

    [DllImport("samlib.dll")]
    private static extern int SamSetInformationUser(
        IntPtr UserHandle,
        USER_INFORMATION_CLASS UserInformationClass,
        ref SAMPR_USER_INFO_BUFFER Buffer);

    [DllImport("samlib.dll")]
    private static extern int SamCloseHandle(IntPtr SamHandle);

    [DllImport("samlib.dll")]
    private static extern int SamFreeMemory(IntPtr Buffer);

    [DllImport("Netapi32.dll", CharSet = CharSet.Unicode)]
    private static extern int NetGetDCName(string ServerName, string DomainName, out IntPtr Buffer);

    [DllImport("Netapi32.dll")]
    private static extern int NetApiBufferFree(IntPtr Buffer);

    [DllImport("advapi32.dll")]
    private static extern int LsaNtStatusToWinError(int status);

    private const uint SAM_SERVER_CONNECT = 0x00000001;
    private const uint SAM_SERVER_LOOKUP_DOMAIN = 0x00000020;
    private const uint DOMAIN_LOOKUP = 0x00000200;
    private const uint USER_FORCE_PASSWORD_CHANGE = 0x00000080;

    private struct UserIdentity
    {
        public string Domain;
        public string User;
    }

    public static void SetPassword(string userInput, string newPassword)
    {
        if (string.IsNullOrWhiteSpace(userInput))
            throw new ArgumentException("User name must not be empty.", "user");
        if (string.IsNullOrEmpty(newPassword))
            throw new ArgumentException("New password must not be empty.", "newPassword");

        var identity = ParseIdentity(userInput);
        string dcName = GetDomainControllerName(identity.Domain);

        UNICODE_STRING serverName = ToUnicodeString(dcName);
        UNICODE_STRING domainName = ToUnicodeString(identity.Domain);
        UNICODE_STRING userName = ToUnicodeString(identity.User);

        IntPtr serverHandle = IntPtr.Zero;
        IntPtr domainHandle = IntPtr.Zero;
        IntPtr userHandle = IntPtr.Zero;
        IntPtr domainSid = IntPtr.Zero;
        IntPtr ridArray = IntPtr.Zero;
        IntPtr useArray = IntPtr.Zero;

        try
        {
            EnsureNtSuccess(SamConnect(ref serverName, out serverHandle, SAM_SERVER_CONNECT | SAM_SERVER_LOOKUP_DOMAIN, false), "SamConnect");
            EnsureNtSuccess(SamLookupDomainInSamServer(serverHandle, ref domainName, out domainSid), "SamLookupDomainInSamServer");
            EnsureNtSuccess(SamOpenDomain(serverHandle, DOMAIN_LOOKUP, domainSid, out domainHandle), "SamOpenDomain");

            UNICODE_STRING[] names = new[] { userName };
            EnsureNtSuccess(SamLookupNamesInDomain(domainHandle, 1, names, out ridArray, out useArray), "SamLookupNamesInDomain");
            uint rid = (uint)Marshal.ReadInt32(ridArray);

            EnsureNtSuccess(SamOpenUser(domainHandle, USER_FORCE_PASSWORD_CHANGE, rid, out userHandle), "SamOpenUser");

            byte[] ntHash = Md4Unicode(newPassword);
            SAMPR_USER_INFO_BUFFER buffer = new SAMPR_USER_INFO_BUFFER
            {
                Internal1 = new SAMPR_USER_INTERNAL1_INFORMATION
                {
                    NTHash = ntHash,
                    LMHash = new byte[16],
                    NtPasswordPresent = 1,
                    LmPasswordPresent = 0,
                    PasswordExpired = 0,
                    PrivateDataSensitive = 0
                }
            };

            EnsureNtSuccess(SamSetInformationUser(userHandle, USER_INFORMATION_CLASS.UserInternal1Information, ref buffer), "SamSetInformationUser");
        }
        finally
        {
            if (ridArray != IntPtr.Zero)
                SamFreeMemory(ridArray);
            if (useArray != IntPtr.Zero)
                SamFreeMemory(useArray);
            if (domainSid != IntPtr.Zero)
                SamFreeMemory(domainSid);
            if (userHandle != IntPtr.Zero)
                SamCloseHandle(userHandle);
            if (domainHandle != IntPtr.Zero)
                SamCloseHandle(domainHandle);
            if (serverHandle != IntPtr.Zero)
                SamCloseHandle(serverHandle);
            FreeUnicodeString(ref userName);
            FreeUnicodeString(ref domainName);
            FreeUnicodeString(ref serverName);
        }
    }

    private static void EnsureNtSuccess(int status, string operation)
    {
        if (status != 0)
        {
            int win32 = LsaNtStatusToWinError(status);
            string message = string.Format("{0} failed with NTSTATUS 0x{1:X8}", operation, status);
            throw new Win32Exception(win32 != 0 ? win32 : status, message);
        }
    }

    private static UserIdentity ParseIdentity(string userInput)
    {
        string domain = null;
        string user = userInput;

        int slashIndex = userInput.IndexOf('\\');
        if (slashIndex >= 0)
        {
            domain = userInput.Substring(0, slashIndex);
            user = userInput.Substring(slashIndex + 1);
        }
        else
        {
            int atIndex = userInput.IndexOf('@');
            if (atIndex >= 0)
            {
                user = userInput.Substring(0, atIndex);
                domain = userInput.Substring(atIndex + 1);
            }
        }

        if (string.IsNullOrWhiteSpace(domain))
            domain = Environment.UserDomainName;
        if (string.IsNullOrWhiteSpace(domain))
            domain = Environment.MachineName;

        return new UserIdentity { Domain = domain, User = user };
    }

    private static string GetDomainControllerName(string domain)
    {
        if (string.IsNullOrWhiteSpace(domain))
            throw new ArgumentException("Domain must not be empty.", "domain");

        IntPtr buffer;
        int status = NetGetDCName(null, domain, out buffer);
        if (status != 0)
            throw new Win32Exception(status, string.Format("NetGetDCName failed for domain '{0}'", domain));

        string server = Marshal.PtrToStringUni(buffer);
        NetApiBufferFree(buffer);

        if (string.IsNullOrWhiteSpace(server))
            throw new InvalidOperationException("Unable to determine a domain controller name.");

        return server;
    }

    private static UNICODE_STRING ToUnicodeString(string value)
    {
        UNICODE_STRING str = new UNICODE_STRING();
        str.Buffer = Marshal.StringToHGlobalUni(value);
        str.Length = (ushort)(value.Length * 2);
        str.MaximumLength = (ushort)(str.Length + 2);
        return str;
    }

    private static void FreeUnicodeString(ref UNICODE_STRING str)
    {
        if (str.Buffer != IntPtr.Zero)
        {
            Marshal.FreeHGlobal(str.Buffer);
            str.Buffer = IntPtr.Zero;
            str.Length = 0;
            str.MaximumLength = 0;
        }
    }

    private static byte[] Md4Unicode(string value)
    {
        byte[] data = Encoding.Unicode.GetBytes(value);
        using (var md4 = new MD4Managed())
        {
            return md4.ComputeHash(data);
        }
    }

    private sealed class MD4Managed : HashAlgorithm
    {
        private readonly uint[] _state = new uint[4];
        private readonly uint[] _count = new uint[2];
        private readonly byte[] _buffer = new byte[64];
        private readonly uint[] _x = new uint[16];

        public MD4Managed()
        {
            HashSizeValue = 128;
            Initialize();
        }

        public override void Initialize()
        {
            _count[0] = _count[1] = 0;
            _state[0] = 0x67452301;
            _state[1] = 0xefcdab89;
            _state[2] = 0x98badcfe;
            _state[3] = 0x10325476;
        }

        protected override void HashCore(byte[] array, int ibStart, int cbSize)
        {
            int i = ibStart;
            int inputLen = cbSize;
            int index = (int)((_count[0] >> 3) & 0x3F);
            _count[0] += (uint)(inputLen << 3);
            if (_count[0] < (inputLen << 3)) _count[1]++;
            _count[1] += (uint)(inputLen >> 29);

            int partLen = 64 - index;
            int k = 0;
            if (inputLen >= partLen)
            {
                Buffer.BlockCopy(array, i, _buffer, index, partLen);
                Transform(_buffer, 0);
                for (k = partLen; k + 63 < inputLen; k += 64)
                    Transform(array, i + k);
                index = 0;
            }
            Buffer.BlockCopy(array, i + k, _buffer, index, inputLen - k);
        }

        protected override byte[] HashFinal()
        {
            byte[] digest = new byte[16];
            byte[] bits = new byte[8];
            Encode(bits, _count, 8);

            int index = (int)((_count[0] >> 3) & 0x3f);
            int padLen = (index < 56) ? (56 - index) : (120 - index);
            byte[] padding = new byte[padLen + 8];
            padding[0] = 0x80;
            Buffer.BlockCopy(bits, 0, padding, padLen, 8);
            HashCore(padding, 0, padding.Length);

            Encode(digest, _state, 16);
            return digest;
        }

        private void Transform(byte[] block, int offset)
        {
            for (int i = 0, j = offset; i < 16; i++, j += 4)
                _x[i] = (uint)(block[j] | (block[j + 1] << 8) | (block[j + 2] << 16) | (block[j + 3] << 24));

            uint a = _state[0], b = _state[1], c = _state[2], d = _state[3];

            FF(ref a, b, c, d, _x[0], 3); FF(ref d, a, b, c, _x[1], 7);
            FF(ref c, d, a, b, _x[2], 11); FF(ref b, c, d, a, _x[3], 19);
            FF(ref a, b, c, d, _x[4], 3); FF(ref d, a, b, c, _x[5], 7);
            FF(ref c, d, a, b, _x[6], 11); FF(ref b, c, d, a, _x[7], 19);
            FF(ref a, b, c, d, _x[8], 3); FF(ref d, a, b, c, _x[9], 7);
            FF(ref c, d, a, b, _x[10], 11); FF(ref b, c, d, a, _x[11], 19);
            FF(ref a, b, c, d, _x[12], 3); FF(ref d, a, b, c, _x[13], 7);
            FF(ref c, d, a, b, _x[14], 11); FF(ref b, c, d, a, _x[15], 19);

            GG(ref a, b, c, d, _x[0], 3); GG(ref d, a, b, c, _x[4], 5);
            GG(ref c, d, a, b, _x[8], 9); GG(ref b, c, d, a, _x[12], 13);
            GG(ref a, b, c, d, _x[1], 3); GG(ref d, a, b, c, _x[5], 5);
            GG(ref c, d, a, b, _x[9], 9); GG(ref b, c, d, a, _x[13], 13);
            GG(ref a, b, c, d, _x[2], 3); GG(ref d, a, b, c, _x[6], 5);
            GG(ref c, d, a, b, _x[10], 9); GG(ref b, c, d, a, _x[14], 13);
            GG(ref a, b, c, d, _x[3], 3); GG(ref d, a, b, c, _x[7], 5);
            GG(ref c, d, a, b, _x[11], 9); GG(ref b, c, d, a, _x[15], 13);

            HH(ref a, b, c, d, _x[0], 3); HH(ref d, a, b, c, _x[8], 9);
            HH(ref c, d, a, b, _x[4], 11); HH(ref b, c, d, a, _x[12], 15);
            HH(ref a, b, c, d, _x[2], 3); HH(ref d, a, b, c, _x[10], 9);
            HH(ref c, d, a, b, _x[6], 11); HH(ref b, c, d, a, _x[14], 15);
            HH(ref a, b, c, d, _x[1], 3); HH(ref d, a, b, c, _x[9], 9);
            HH(ref c, d, a, b, _x[5], 11); HH(ref b, c, d, a, _x[13], 15);
            HH(ref a, b, c, d, _x[3], 3); HH(ref d, a, b, c, _x[11], 9);
            HH(ref c, d, a, b, _x[7], 11); HH(ref b, c, d, a, _x[15], 15);

            _state[0] += a; _state[1] += b; _state[2] += c; _state[3] += d;
        }

        private static void Encode(byte[] output, uint[] input, int len)
        {
            int i = 0, j = 0;
            while (j < len)
            {
                uint value = input[i++];
                output[j++] = (byte)(value & 0xff);
                output[j++] = (byte)((value >> 8) & 0xff);
                output[j++] = (byte)((value >> 16) & 0xff);
                output[j++] = (byte)((value >> 24) & 0xff);
            }
        }

        private static void FF(ref uint a, uint b, uint c, uint d, uint xk, int s)
        {
            a = RotateLeft(a + F(b, c, d) + xk, s);
        }

        private static void GG(ref uint a, uint b, uint c, uint d, uint xk, int s)
        {
            a = RotateLeft(a + G(b, c, d) + xk + 0x5a827999, s);
        }

        private static void HH(ref uint a, uint b, uint c, uint d, uint xk, int s)
        {
            a = RotateLeft(a + H(b, c, d) + xk + 0x6ed9eba1, s);
        }

        private static uint F(uint x, uint y, uint z)
        {
            return (x & y) | (~x & z);
        }

        private static uint G(uint x, uint y, uint z)
        {
            return (x & y) | (x & z) | (y & z);
        }

        private static uint H(uint x, uint y, uint z)
        {
            return x ^ y ^ z;
        }

        private static uint RotateLeft(uint x, int n)
        {
            return (x << n) | (x >> (32 - n));
        }
    }
}
"@

function Set-NtlmPassword {
    param(
        [Parameter(Mandatory = $true)][string]$UserName,
        [Parameter(Mandatory = $true)][string]$NewPassword
    )
    [SetNtlmHelper]::SetPassword($UserName, $NewPassword)
}

Set-NtlmPassword -UserName $UserName -NewPassword $NewPassword
